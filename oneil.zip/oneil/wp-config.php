<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'oneil' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'L8;VE8Y(O_z2#pcb75g(8y}_WiQPo.E!y7w>G;=Mj7R30X7$;[XomTp[T)Ol`HTh' );
define( 'SECURE_AUTH_KEY',  '1_eGL0&a{OU[5ooi7P0>UQh<m/0Yq| C&pNYl&V,p+OYzyVcMRqW$i3{Qki0mk] ' );
define( 'LOGGED_IN_KEY',    '&RylZdZ=,yl=CbwY>WJtrLrE)(W>C.7a7W<94WXf|L$4:ByY}Iez,Xd!9C?uf[T,' );
define( 'NONCE_KEY',        '^m:IL8F:Ph;(3lWvHo!|bzElZ4BUF1)3hshC%Y5KNf!x]:|NI+pS]j<[fSi;,:m-' );
define( 'AUTH_SALT',        ')Z`*=Y$Ewcm,{N94z=BCfKr5q)GvSSiN^e+S!blrWO/[w@yo%b#bghg&<>8,RZ;,' );
define( 'SECURE_AUTH_SALT', '9egdwQ<,=R]pM$7`3*i8&/gm8H)k.*+z)_b$zR9eK;s}DqUWT|kZ(0ia!N HCMh4' );
define( 'LOGGED_IN_SALT',   'HLv2_5<r0p+-rqUXw|39o{(2j!a.`0/3q5r`Y9dj!]=nA&IaGz&(.{,37x3{7R#H' );
define( 'NONCE_SALT',       '/TQuK<!0$;%QyT~iBez`^lhP=D[i+&9Z{ojCWb&MfMXds2EfS`im;0(B7?Fn`Wh0' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
